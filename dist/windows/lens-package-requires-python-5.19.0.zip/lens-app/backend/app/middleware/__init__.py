"""Middleware package for FastAPI application."""
