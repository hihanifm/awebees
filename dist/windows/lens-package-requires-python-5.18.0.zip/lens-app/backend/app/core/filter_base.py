from enum import Enum
from typing import List, Optional, Dict, Callable, Awaitable, Any
from dataclasses import dataclass
import re
import logging
import asyncio
import os
from pathlib import Path
from app.core.insight_base import Insight
from app.core.models import InsightResult, ProgressEvent
from app.services.file_handler import read_file_lines, read_file_chunks, CancelledError, parse_zip_path, extract_file_from_zip, ZIP_VIRTUAL_PATH_SEPARATOR, is_zip_file, list_zip_contents
from app.utils.ripgrep import is_ripgrep_available, ripgrep_search, build_ripgrep_command

logger = logging.getLogger(__name__)


class ReadingMode(Enum):
    """File reading mode for line filtering."""
    LINES = "lines"  # Line-by-line reading using read_file_lines()
    CHUNKS = "chunks"  # Chunk-based reading using read_file_chunks()
    RIPGREP = "ripgrep"  # Use ripgrep for ultra-fast pattern matching (10-100x faster)


class FilterResult:
    """Result of filtering operations with filtered lines grouped by file."""
    
    def __init__(self):
        self._lines_by_file: Dict[str, List[str]] = {}
        self._commands_by_file: Dict[str, str] = {}  # Store execution command per file
        self._execution_method: Optional[str] = None  # Store execution method used
    
    def add_line(self, file_path: str, line: str) -> None:
        if file_path not in self._lines_by_file:
            self._lines_by_file[file_path] = []
        self._lines_by_file[file_path].append(line)
    
    def set_command(self, file_path: str, command: str) -> None:
        self._commands_by_file[file_path] = command
    
    def set_execution_method(self, method: str) -> None:
        # Valid values: ripgrep, python_lines, python_chunks, custom
        self._execution_method = method
    
    def get_command(self, file_path: str) -> Optional[str]: return self._commands_by_file.get(file_path)
    
    def get_commands(self) -> Dict[str, str]: return self._commands_by_file.copy()
    
    def get_execution_method(self) -> Optional[str]: return self._execution_method
    
    def get_lines(self) -> List[str]:
        all_lines = []
        for lines in self._lines_by_file.values():
            all_lines.extend(lines)
        return all_lines
    
    def get_lines_by_file(self) -> Dict[str, List[str]]: return self._lines_by_file.copy()
    
    def get_file_count(self) -> int: return len(self._lines_by_file)
    
    def get_total_line_count(self) -> int: return sum(len(lines) for lines in self._lines_by_file.values())


@dataclass
class LineFilterConfig:
    """Configuration for a line filter."""
    pattern: str
    reading_mode: ReadingMode = ReadingMode.RIPGREP
    chunk_size: int = 1048576
    regex_flags: int = 0
    processing: Optional[Callable[[FilterResult], Dict[str, Any]]] = None
    
    def to_line_filter(self) -> 'LineFilter':
        """Create LineFilter instance from this config."""
        return LineFilter(
            pattern=self.pattern,
            reading_mode=self.reading_mode,
            chunk_size=self.chunk_size,
            flags=self.regex_flags
        )


@dataclass
class FileFilterConfig:
    """Configuration for a file filter with its line filters."""
    file_patterns: Optional[List[str]]  # None = default dummy filter (all files)
    line_filters: List[LineFilterConfig]
    processing: Optional[Callable[[List[Dict[str, Any]]], Dict[str, Any]]] = None  # file-filter level processing


@dataclass
class ExecutionGraph:
    """Complete execution graph for an insight."""
    file_filters: List[FileFilterConfig]
    final_processing: Optional[Callable[[List[Dict[str, Any]]], Dict[str, Any]]] = None


class FileFilter:
    """Builder class for filtering files from folders with regex patterns."""
    
    def __init__(self, file_paths: List[str]):
        self._file_paths = file_paths
        self._filtered_files: Optional[List[str]] = None
        self._file_patterns: List[str] = []
    
    def _list_files_sync(self, folder_path: str) -> List[str]:
        folder = Path(folder_path)
        if not folder.is_dir():
            return []
        files = [str(p.resolve()) for p in folder.rglob("*") if p.is_file()]
        return sorted(files)
    
    def filter_files(self, *patterns: str) -> 'FileFilter':
        """
        Apply file filtering patterns to files and folders.
        
        Patterns match against the filename only (not the full path).
        For virtual zip paths (zip_path::internal/file.txt), matches against the internal filename.
        Multiple patterns use OR logic - a file matches if it matches any pattern.
        
        Args:
            *patterns: One or more regex patterns for filtering files
            
        Returns:
            Self for chaining
        """
        self._file_patterns = list(patterns)
        self._filtered_files = None  # Reset filtered files
        return self
    
    def get_files(self) -> List[str]:
        """
        Get filtered file list.
        
        Returns:
            List of file paths (filtered if patterns were applied)
        """
        if self._filtered_files is not None:
            logger.debug(f"FileFilter: Returning cached file list ({len(self._filtered_files)} files)")
            return self._filtered_files
        
        logger.info(f"FileFilter: Processing {len(self._file_paths)} input path(s)")
        all_files = []
        
        # Collect virtual paths separately to apply patterns
        virtual_paths = []
        real_paths = []
        
        for path in self._file_paths:
            if ZIP_VIRTUAL_PATH_SEPARATOR in path:
                virtual_paths.append(path)
            else:
                real_paths.append(path)
        
        # Apply patterns to virtual paths if patterns are set
        import re
        if self._file_patterns and len(self._file_patterns) > 0 and virtual_paths:
            compiled_patterns = [re.compile(pattern) for pattern in self._file_patterns]
            matching_virtual = []
            for file_path in virtual_paths:
                # Extract filename from virtual path
                _, internal_path = file_path.split(ZIP_VIRTUAL_PATH_SEPARATOR, 1)
                file_name = Path(internal_path).name
                if any(pattern.search(file_name) for pattern in compiled_patterns):
                    matching_virtual.append(file_path)
            all_files.extend(matching_virtual)
        elif virtual_paths:
            # No patterns: include all virtual paths
            all_files.extend(virtual_paths)
        
        # Process real paths (files and folders)
        for path in real_paths:
            path_obj = Path(path)
            
            if path_obj.is_file():
                resolved_path = str(path_obj.resolve())
                # Check if it's a zip file - if so, list its contents
                if is_zip_file(resolved_path):
                    logger.info(f"FileFilter: Expanding zip file: {resolved_path}")
                    try:
                        zip_files = list_zip_contents(resolved_path, recursive=True)
                        logger.debug(f"FileFilter: Found {len(zip_files)} file(s) inside zip {resolved_path}")
                        all_files.extend(zip_files)
                    except Exception as e:
                        logger.error(f"FileFilter: Error listing zip contents {resolved_path}: {e}", exc_info=True)
                        # Fall back to treating it as a regular file
                        logger.warning(f"FileFilter: Falling back to treating {resolved_path} as regular file")
                        all_files.append(resolved_path)
                else:
                    # Individual file paths: apply patterns if set, otherwise pass through
                    if self._file_patterns and len(self._file_patterns) > 0:
                        file_name = path_obj.name
                        compiled_patterns = [re.compile(pattern) for pattern in self._file_patterns]
                        if any(pattern.search(file_name) for pattern in compiled_patterns):
                            logger.debug(f"FileFilter: Added individual file (matched pattern): {resolved_path}")
                            all_files.append(resolved_path)
                        else:
                            logger.debug(f"FileFilter: Skipped individual file (no pattern match): {resolved_path}")
                    else:
                        logger.debug(f"FileFilter: Added individual file: {resolved_path}")
                        all_files.append(resolved_path)
            elif path_obj.is_dir():
                # Folder paths: expand to files and apply filtering
                try:
                    logger.info(f"FileFilter: Expanding folder: {path}")
                    # Use sync file listing (list_files_in_folder is async but we're in sync context)
                    folder_files = self._list_files_sync(str(path_obj.resolve()))
                    logger.debug(f"FileFilter: Found {len(folder_files)} files in folder {path}")
                    
                    if self._file_patterns and len(self._file_patterns) > 0:
                        # Apply file filtering patterns (OR logic)
                        logger.info(f"FileFilter: Applying {len(self._file_patterns)} file filter pattern(s): {self._file_patterns}")
                        try:
                            compiled_patterns = [re.compile(pattern) for pattern in self._file_patterns]
                            matching_files = []
                            for file_path in folder_files:
                                # Extract filename - handle virtual zip paths (zip_path::internal/file.txt)
                                if ZIP_VIRTUAL_PATH_SEPARATOR in file_path:
                                    _, internal_path = file_path.split(ZIP_VIRTUAL_PATH_SEPARATOR, 1)
                                    file_name = Path(internal_path).name
                                else:
                                    file_name = Path(file_path).name
                                if any(pattern.search(file_name) for pattern in compiled_patterns):
                                    matching_files.append(file_path)
                            logger.info(f"FileFilter: {len(matching_files)} files matched filter pattern(s) from {len(folder_files)} total files in folder {path}")
                            all_files.extend(matching_files)
                        except re.error as e:
                            logger.error(f"FileFilter: Invalid regex pattern in file_patterns: {e}", exc_info=True)
                            # Fall back to including all files if pattern is invalid
                            logger.warning(f"FileFilter: Falling back to including all {len(folder_files)} files due to pattern error")
                            all_files.extend(folder_files)
                    else:
                        # No patterns: include all files
                        logger.debug(f"FileFilter: No file filter patterns specified, including all {len(folder_files)} files from folder {path}")
                        all_files.extend(folder_files)
                except Exception as e:
                    logger.error(f"FileFilter: Error processing folder {path}: {e}", exc_info=True)
                    # Continue with other paths
            else:
                logger.warning(f"FileFilter: Path is neither file nor folder: {path}")
        
        # Remove duplicates while preserving order
        seen = set()
        unique_files = []
        for file_path in all_files:
            if file_path not in seen:
                seen.add(file_path)
                unique_files.append(file_path)
        
        logger.info(f"FileFilter: Final file list: {len(unique_files)} unique file(s)")
        self._filtered_files = unique_files
        return self._filtered_files
    
    async def apply(self, line_filter: 'LineFilter', cancellation_event: Optional[asyncio.Event] = None, progress_callback: Optional[Callable[[ProgressEvent], Awaitable[None]]] = None) -> FilterResult:
        """
        Apply line filter to filtered files.
        
        Args:
            line_filter: LineFilter instance to apply
            cancellation_event: Optional asyncio.Event to check for cancellation
            progress_callback: Optional async callback to emit progress events
            
        Returns:
            FilterResult with filtered lines
        """
        files = self.get_files()
        return await line_filter.filter_lines(files, cancellation_event, progress_callback)


class LineFilter:
    """Filter class for filtering lines within files using regex patterns."""
    
    def __init__(
        self,
        pattern: str,
        reading_mode: ReadingMode = ReadingMode.LINES,
        chunk_size: int = 1048576,
        flags: int = 0
    ):
        """
        Initialize line filter.
        
        Args:
            pattern: Regex pattern for filtering lines
            reading_mode: Reading mode - LINES (default) or CHUNKS
            chunk_size: Chunk size in bytes (only used for CHUNKS mode, default: 1MB)
            flags: Regex flags (e.g., re.IGNORECASE)
        """
        self.pattern = pattern
        self.reading_mode = reading_mode
        self.chunk_size = chunk_size
        self.flags = flags
        self._compiled_pattern = re.compile(pattern, flags)
    
    async def filter_lines(
        self,
        file_paths: List[str],
        cancellation_event: Optional[asyncio.Event] = None,
        progress_callback: Optional[Callable[[ProgressEvent], Awaitable[None]]] = None,
        task_id: Optional[str] = None
    ) -> FilterResult:
        # task_id parameter is kept for backward compatibility, but we'll use context variable if not provided
        """
        Filter lines from files using the configured pattern and reading mode.
        
        Args:
            file_paths: List of file paths to process
            cancellation_event: Optional asyncio.Event to check for cancellation
            progress_callback: Optional async callback to emit progress events
            
        Returns:
            FilterResult with filtered lines
            
        Raises:
            CancelledError: If operation is cancelled
        """
        import time
        result = FilterResult()
        logger.info(f"LineFilter: Starting line filtering with pattern '{self.pattern}' (mode: {self.reading_mode.value}, flags: {self.flags})")
        logger.info(f"LineFilter: Processing {len(file_paths)} file(s)")
        
        for file_idx, file_path in enumerate(file_paths, 1):
            # Check for cancellation at start of each file
            if cancellation_event and cancellation_event.is_set():
                logger.info(f"LineFilter: Analysis cancelled before processing file {file_idx}/{len(file_paths)}")
                raise CancelledError("Analysis cancelled")
            
            file_start_time = time.time()
            logger.info(f"LineFilter: Processing file {file_idx}/{len(file_paths)}: {file_path}")
            
            # Get file size for progress tracking
            file_size_mb = 0.0
            try:
                # Skip size check for zip virtual paths (can't use os.path.getsize)
                if ZIP_VIRTUAL_PATH_SEPARATOR not in file_path:
                    file_size_bytes = os.path.getsize(file_path)
                    file_size_mb = file_size_bytes / (1024 * 1024)
                    logger.debug(f"LineFilter: File size: {file_size_mb:.2f} MB ({file_size_bytes:,} bytes)")
            except Exception as e:
                logger.warning(f"LineFilter: Could not get file size for {file_path}: {e}")
            
            # Emit file_open event
            if progress_callback:
                try:
                    await progress_callback(ProgressEvent(
                        type="file_open",
                        message=f"Opening file {file_idx}/{len(file_paths)}: {os.path.basename(file_path)}",
                        task_id="",  # Will be set by callback
                        insight_id="",  # Will be set by callback
                        file_path=file_path,
                        file_index=file_idx,
                        total_files=len(file_paths),
                        file_size_mb=file_size_mb
                    ))
                    logger.debug(f"LineFilter: file_open event emitted for {file_path}")
                except Exception as e:
                    logger.error(f"LineFilter: Error emitting file_open event: {e}", exc_info=True)
            else:
                logger.debug(f"LineFilter: No progress_callback provided, skipping file_open event")
            
            try:
                file_lines = []
                execution_method = None
                command = None
                
                if self.reading_mode == ReadingMode.LINES:
                    # Line-by-line reading mode
                    logger.debug(f"LineFilter: Using line-by-line reading mode for {file_path}")
                    file_lines, command = await self._filter_lines_mode(file_path, cancellation_event)
                    execution_method = "python_lines"
                elif self.reading_mode == ReadingMode.CHUNKS:
                    # Chunk-based reading mode
                    logger.debug(f"LineFilter: Using chunk-based reading mode (chunk_size: {self.chunk_size:,} bytes) for {file_path}")
                    file_lines, command = await self._filter_chunks_mode(file_path, cancellation_event)
                    execution_method = "python_chunks"
                elif self.reading_mode == ReadingMode.RIPGREP:
                    # Ripgrep mode - ultra-fast pattern matching
                    if not is_ripgrep_available():
                        logger.warning(f"LineFilter: Ripgrep not available, falling back to line-by-line mode")
                        file_lines, command = await self._filter_lines_mode(file_path, cancellation_event)
                        execution_method = "python_lines"
                    else:
                        logger.debug(f"LineFilter: Using ripgrep mode (10-100x faster) for {file_path}")
                        file_lines, command = await self._filter_ripgrep_mode(file_path, cancellation_event, progress_callback, task_id)
                        execution_method = "ripgrep"
                
                # Store execution method (use first file's method as representative)
                if result.get_execution_method() is None:
                    result.set_execution_method(execution_method)
                
                # Store command for this file
                if command:
                    result.set_command(file_path, command)
                
                # Store filtered lines
                for line in file_lines:
                    result.add_line(file_path, line)
                
                file_elapsed = time.time() - file_start_time
                logger.info(f"LineFilter: Completed {file_path} - {len(file_lines)} matching lines found in {file_elapsed:.2f}s ({len(file_lines)/file_elapsed:.1f} lines/sec)")
                
                # Emit progress event after file processing
                if progress_callback:
                    try:
                        await progress_callback(ProgressEvent(
                            type="insight_progress",
                            message=f"Processed {os.path.basename(file_path)}: {len(file_lines)} matching lines",
                            task_id="",  # Will be set by callback
                            insight_id="",  # Will be set by callback
                            file_path=file_path,
                            file_index=file_idx,
                            total_files=len(file_paths),
                            lines_processed=0,  # Not tracking line numbers in simple mode
                            file_size_mb=file_size_mb
                        ))
                        logger.debug(f"LineFilter: Progress event emitted for {file_path}")
                    except Exception as e:
                        logger.error(f"LineFilter: Error emitting progress event: {e}", exc_info=True)
                        
            except CancelledError:
                logger.info(f"LineFilter: Analysis cancelled while processing {file_path}")
                raise
            except Exception as e:
                logger.error(f"LineFilter: Failed to process {file_path}: {e}", exc_info=True)
                # Continue with other files
        
        total_lines = result.get_total_line_count()
        file_count = result.get_file_count()
        logger.info(f"LineFilter: Line filtering complete - {total_lines} total matching lines across {file_count} file(s)")
        return result
    
    async def _filter_lines_mode(
        self,
        file_path: str,
        cancellation_event: Optional[asyncio.Event] = None
    ) -> tuple[List[str], str]:
        matching_lines = []
        total_lines_checked = 0
        
        logger.debug(f"LineFilter: Starting line-by-line filtering for {file_path}")
        for line in read_file_lines(file_path, cancellation_event=cancellation_event):
            total_lines_checked += 1
            if self._compiled_pattern.search(line):
                matching_lines.append(line)
        logger.debug(f"LineFilter: Line-by-line filtering complete - {len(matching_lines)} matches from {total_lines_checked:,} lines checked")
        
        # Build command representation
        import re
        flags_str = ""
        if self.flags & re.IGNORECASE:
            flags_str = " --ignore-case"
        command = f"python line-by-line search: {self.pattern}{flags_str} {file_path}"
        
        return matching_lines, command
    
    async def _filter_chunks_mode(
        self,
        file_path: str,
        cancellation_event: Optional[asyncio.Event] = None
    ) -> tuple[List[str], str]:
        matching_lines = []
        chunk_buffer = ""  # Buffer for incomplete lines at chunk boundaries
        chunk_count = 0
        total_lines_checked = 0
        
        logger.debug(f"LineFilter: Starting chunk-based filtering for {file_path} (chunk_size: {self.chunk_size:,} bytes)")
        for chunk in read_file_chunks(file_path, chunk_size=self.chunk_size, cancellation_event=cancellation_event):
            chunk_count += 1
            # Combine chunk with buffer (handles lines split across chunks)
            text_to_process = chunk_buffer + chunk
            chunk_buffer = ""  # Clear buffer, will rebuild if needed
            
            # Process chunk line by line
            if text_to_process:
                # Find last newline to determine if chunk ends with complete line
                last_newline_idx = text_to_process.rfind('\n')
                if last_newline_idx == -1:
                    last_newline_idx = text_to_process.rfind('\r')
                
                if last_newline_idx == -1:
                    # No newline in this chunk, entire chunk is incomplete line
                    chunk_buffer = text_to_process
                else:
                    # Split at newlines, keep complete lines
                    complete_text = text_to_process[:last_newline_idx + 1]
                    lines = complete_text.splitlines(keepends=True)
                    # Save any incomplete line after last newline as buffer
                    if last_newline_idx + 1 < len(text_to_process):
                        chunk_buffer = text_to_process[last_newline_idx + 1:]
                    
                    # Apply regex pattern to each complete line
                    for line in lines:
                        total_lines_checked += 1
                        if self._compiled_pattern.search(line):
                            matching_lines.append(line)
        
        # Process any remaining buffer content (last incomplete line if file doesn't end with newline)
        if chunk_buffer.strip():
            total_lines_checked += 1
            if self._compiled_pattern.search(chunk_buffer):
                matching_lines.append(chunk_buffer)
        
        logger.debug(f"LineFilter: Chunk-based filtering complete - {len(matching_lines)} matches from {total_lines_checked:,} lines checked across {chunk_count} chunk(s)")
        
        # Build command representation
        import re
        flags_str = ""
        if self.flags & re.IGNORECASE:
            flags_str = " --ignore-case"
        command = f"python chunk-based search: {self.pattern}{flags_str} {file_path}"
        
        return matching_lines, command
    
    async def _filter_ripgrep_mode(
        self,
        file_path: str,
        cancellation_event: Optional[asyncio.Event] = None,
        progress_callback: Optional[Callable[[ProgressEvent], Awaitable[None]]] = None,
        task_id: Optional[str] = None
    ) -> tuple[List[str], str]:
        # task_id parameter is kept for backward compatibility, but we'll use context variable if not provided
        matching_lines = []
        
        logger.debug(f"LineFilter: Starting ripgrep filtering for {file_path}")
        
        # Check if it's a zip virtual path
        zip_path_info = parse_zip_path(file_path)
        actual_file_path = file_path
        
        if zip_path_info:
            zip_path, internal_path = zip_path_info
            logger.debug(f"LineFilter: Detected zip virtual path: {file_path}")
            
            # Get task_id from context variable if not provided
            if task_id is None:
                from app.core.task_manager import get_context_param
                task_id = get_context_param("task_id")
            
            if not task_id:
                logger.warning(f"LineFilter: Cannot extract zip file {file_path} for ripgrep - task_id not available in context. Skipping file.")
                return [], f"zip extraction skipped (no task_id): {file_path}"
            
            # Get task temp directory and extract file
            try:
                from app.core.task_manager import get_task_manager
                task_manager = get_task_manager()
                temp_dir = task_manager.get_task_temp_dir(task_id)
                
                if not temp_dir:
                    logger.warning(f"LineFilter: Cannot get temp directory for task {task_id}. Skipping zip file {file_path}.")
                    return [], f"zip extraction skipped (no temp dir): {file_path}"
                
                # Extract file to temp directory
                extracted_path = extract_file_from_zip(zip_path, internal_path, temp_dir)
                
                if not extracted_path:
                    logger.warning(f"LineFilter: Failed to extract zip file {file_path}. Skipping file.")
                    return [], f"zip extraction failed: {file_path}"
                
                actual_file_path = str(extracted_path)
                logger.debug(f"LineFilter: Extracted zip file to {actual_file_path} for ripgrep")
                
            except Exception as e:
                logger.error(f"LineFilter: Error extracting zip file {file_path}: {e}. Skipping file.")
                return [], f"zip extraction error: {file_path}"
        
        try:
            # Check for cancellation before starting
            if cancellation_event and cancellation_event.is_set():
                raise CancelledError("Analysis cancelled")
            
            # Build ripgrep command for display
            command = build_ripgrep_command(
                ripgrep_command=self.pattern,  # pattern field now contains ripgrep_command
                file_path=actual_file_path
            )
            
            # Run ripgrep in executor to avoid blocking
            loop = asyncio.get_event_loop()
            
            def run_ripgrep():
                results = []
                try:
                    for line in ripgrep_search(
                        actual_file_path,
                        self.pattern  # pattern field now contains ripgrep_command
                    ):
                        # Check for cancellation periodically
                        if cancellation_event and cancellation_event.is_set():
                            raise CancelledError("Analysis cancelled")
                        results.append(line)
                except Exception as e:
                    logger.error(f"LineFilter: Ripgrep error: {e}")
                    raise
                return results
            
            # Run ripgrep in thread pool to avoid blocking event loop
            matching_lines = await loop.run_in_executor(None, run_ripgrep)
            
            logger.debug(f"LineFilter: Ripgrep filtering complete - {len(matching_lines)} matches found")
            
            return matching_lines, command
            
        except CancelledError:
            logger.info(f"LineFilter: Ripgrep filtering cancelled for {file_path}")
            raise
        except Exception as e:
            logger.error(f"LineFilter: Ripgrep failed for {file_path}: {e}, falling back to line-by-line mode")
            # Fall back to line-by-line mode on error (only for non-zip files or if extraction succeeded but ripgrep failed)
            if not zip_path_info:
                matching_lines, command = await self._filter_lines_mode(file_path, cancellation_event)
                return matching_lines, command
            else:
                # For zip files, if ripgrep fails after extraction, we skip (extraction already succeeded, so file exists)
                logger.warning(f"LineFilter: Ripgrep failed for extracted zip file {file_path}. Skipping file.")
                return [], f"ripgrep failed after extraction: {file_path}"


class FilterBasedInsight(Insight):
    """Base class for filter-based insights that simplifies file and line filtering."""
    
    @property
    def file_filter_patterns(self) -> Optional[List[str]]:
        # None = skip file filtering, List[str] = regex patterns for file filtering (OR logic)
        return None
    
    @property
    def line_filter_pattern(self) -> str:
        raise NotImplementedError("Subclasses must implement line_filter_pattern")
    
    @property
    def reading_mode(self) -> ReadingMode:
        # Valid: RIPGREP (default, 10-100x faster), CHUNKS (250MB+), LINES (most compatible)
        return ReadingMode.RIPGREP
    
    @property
    def chunk_size(self) -> int:
        # Chunk size in bytes (default: 1MB = 1048576)
        return 1048576
    
    async def _process_filtered_lines(
        self,
        filter_result: FilterResult
    ) -> InsightResult:
        """
        Default implementation: format filtered lines into InsightResult with line limit applied.
        Subclasses can override this for custom processing.
        """
        from app.core.config import AppConfig
        
        all_lines = filter_result.get_lines()
        total_count = len(all_lines)
        max_lines = AppConfig.get_result_max_lines()
        
        if total_count > max_lines:
            limited_lines = all_lines[:max_lines]
            content = "\n".join(limited_lines)
            metadata = {
                "line_count": total_count,
                "truncated": True,
                "truncated_to": max_lines,
                "total_lines": total_count
            }
        else:
            content = "\n".join(all_lines)
            metadata = {
                "line_count": total_count,
                "truncated": False,
                "total_lines": total_count
            }
        
        return InsightResult(
            result_type="text",
            content=content,
            metadata=metadata
        )
    
    def _get_path_files(self, user_path: str) -> List[str]:
        """Get files for a single user path (if folder, list recursively; if file, use directly; if zip file, list contents)."""
        from pathlib import Path
        path_obj = Path(user_path)
        if not path_obj.exists():
            logger.warning(f"{self.__class__.__name__}: Path does not exist: {user_path}")
            return []
        
        if path_obj.is_file():
            resolved_path = str(path_obj.resolve())
            # Check if it's a zip file - if so, list its contents
            if is_zip_file(resolved_path):
                logger.info(f"{self.__class__.__name__}: Expanding zip file: {resolved_path}")
                try:
                    zip_files = list_zip_contents(resolved_path, recursive=True)
                    logger.debug(f"{self.__class__.__name__}: Found {len(zip_files)} file(s) inside zip {resolved_path}")
                    return zip_files
                except Exception as e:
                    logger.error(f"{self.__class__.__name__}: Error listing zip contents {resolved_path}: {e}", exc_info=True)
                    # Fall back to treating it as a regular file
                    logger.warning(f"{self.__class__.__name__}: Falling back to treating {resolved_path} as regular file")
                    return [resolved_path]
            else:
                return [resolved_path]
        elif path_obj.is_dir():
            files = [str(p.resolve()) for p in path_obj.rglob("*") if p.is_file()]
            return sorted(files)
        else:
            return []
    
    def _apply_file_patterns(self, files: List[str], file_patterns: List[str]) -> List[str]:
        """Apply file patterns to filter files."""
        if not file_patterns:
            return files
        
        import re
        compiled_patterns = [re.compile(pattern) for pattern in file_patterns]
        filtered_files = []
        for file_path in files:
            # Extract filename - handle virtual zip paths (zip_path::internal/file.txt)
            if ZIP_VIRTUAL_PATH_SEPARATOR in file_path:
                # For virtual paths, use the internal filename part (only the filename, not the path)
                _, internal_path = file_path.split(ZIP_VIRTUAL_PATH_SEPARATOR, 1)
                file_name = Path(internal_path).name
            else:
                file_name = Path(file_path).name
            if any(pattern.search(file_name) for pattern in compiled_patterns):
                filtered_files.append(file_path)
        return filtered_files
    
    def _combine_line_filter_results(self, line_filter_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Combine results from multiple line filters."""
        combined_content = []
        total_lines = 0
        
        for result in line_filter_results:
            content = result.get("content", "")
            combined_content.append(content)
            total_lines += result.get("metadata", {}).get("line_count", 0)
        
        return {
            "content": "\n".join(combined_content),
            "metadata": {"total_lines": total_lines, "line_filter_count": len(line_filter_results)}
        }
    
    def _combine_file_filter_results(self, file_filter_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Combine results from multiple file filters."""
        combined_content = []
        total_file_filters = len(file_filter_results)
        
        for result in file_filter_results:
            content = result.get("content", "")
            combined_content.append(content)
        
        return {
            "content": "\n\n".join(combined_content),
            "metadata": {"file_filter_count": total_file_filters}
        }
    
    async def execute_graph(
        self,
        execution_graph: ExecutionGraph,
        user_path: str,
        cancellation_event: Optional[asyncio.Event] = None,
        progress_callback: Optional[Callable[[ProgressEvent], Awaitable[None]]] = None
    ) -> InsightResult:
        """
        Execute a graph of file-filters and line-filters.
        
        Args:
            execution_graph: ExecutionGraph object with file_filters and final_processing
            user_path: User input path (file or folder)
            cancellation_event: Optional cancellation event
            progress_callback: Optional progress callback
            
        Returns:
            InsightResult
        """
        import time
        start_time = time.time()
        logger.info(f"{self.__class__.__name__}: Starting graph execution for path: {user_path}")
        
        # 1. Get files for path
        path_files = self._get_path_files(user_path)
        if not path_files:
            logger.warning(f"{self.__class__.__name__}: No files found for path: {user_path}")
            return InsightResult(
                result_type="text",
                content=f"No files found for path: {user_path}",
                metadata={"user_path": user_path}
            )
        
        # Check file count limit
        limit_error = self._check_file_limit(path_files, user_path)
        if limit_error:
            return limit_error
        
        # Check if user_path is a single file (file patterns should NOT be applied to individual files)
        # BUT: if it's a zip file that was expanded, we DO want to apply file patterns (path_files will have multiple entries)
        from pathlib import Path
        path_obj = Path(user_path)
        is_single_file = path_obj.is_file() and len(path_files) == 1
        
        # 2. Process each file-filter in the graph
        file_filter_results = []
        for file_filter_config in execution_graph.file_filters:
            # Apply file filtering (or use all files if None/dummy)
            # File patterns should NOT be applied to individual files (only to folder contents or expanded zip files)
            if file_filter_config.file_patterns and not is_single_file:
                filtered_files = self._apply_file_patterns(path_files, file_filter_config.file_patterns)
                # Emit progress event even if filtered_files is empty
                if not filtered_files and progress_callback:
                    try:
                        await progress_callback(ProgressEvent(
                            type="path_result",
                            message=f"Completed analysis for path: {user_path}",
                            task_id="",  # Will be set by callback
                            insight_id="",  # Will be set by callback
                            file_path=user_path,
                            data={
                                "file_patterns": file_filter_config.file_patterns,
                                "matched_files": 0,
                                "total_files": len(path_files)
                            }
                        ))
                        logger.debug(f"{self.__class__.__name__}: path_result event emitted for empty file filter (patterns: {file_filter_config.file_patterns})")
                    except Exception as e:
                        logger.error(f"{self.__class__.__name__}: Error emitting path_result event: {e}", exc_info=True)
            else:
                filtered_files = path_files  # Default dummy filter or single file (pass through)
            
            if not filtered_files:
                continue
            
            # Process each line-filter for this file-filter
            line_filter_results = []
            for line_filter_config in file_filter_config.line_filters:
                # Create LineFilter from config object
                line_filter = line_filter_config.to_line_filter()
                
                # Apply line filter to files
                file_filter_obj = FileFilter(filtered_files)
                filter_result = await file_filter_obj.apply(line_filter, cancellation_event, progress_callback)
                
                # Apply line-filter level processing if provided
                if line_filter_config.processing:
                    processed = line_filter_config.processing(filter_result)
                    line_filter_results.append(processed)
                else:
                    # Default: just return the filtered lines (with limit applied)
                    from app.core.config import AppConfig
                    all_lines = filter_result.get_lines()
                    total_count = len(all_lines)
                    max_lines = AppConfig.get_result_max_lines()
                    
                    if total_count > max_lines:
                        limited_lines = all_lines[:max_lines]
                        line_filter_results.append({
                            "content": "\n".join(limited_lines),
                            "metadata": {
                                "line_count": total_count,
                                "truncated": True,
                                "truncated_to": max_lines,
                                "total_lines": total_count
                            }
                        })
                    else:
                        line_filter_results.append({
                            "content": "\n".join(all_lines),
                            "metadata": {
                                "line_count": total_count,
                                "truncated": False,
                                "total_lines": total_count
                            }
                        })
            
            # Apply file-filter level processing if provided
            if file_filter_config.processing:
                file_filter_result = file_filter_config.processing(line_filter_results)
            else:
                # Default: combine all line-filter results
                file_filter_result = self._combine_line_filter_results(line_filter_results)
            
            file_filter_results.append(file_filter_result)
        
        # 3. Apply final processing if provided
        if execution_graph.final_processing:
            result = execution_graph.final_processing(file_filter_results)
        else:
            # Default: combine all file-filter results
            result = self._combine_file_filter_results(file_filter_results)
        
        # Ensure result is a dict with content and metadata
        if not isinstance(result, dict):
            result = {"content": str(result), "metadata": {}}
        if "content" not in result:
            result["content"] = ""
        if "metadata" not in result:
            result["metadata"] = {}
        
        # Add user_path to metadata
        result["metadata"]["user_path"] = user_path
        
        total_elapsed = time.time() - start_time
        logger.info(f"{self.__class__.__name__}: Graph execution complete for path '{user_path}' in {total_elapsed:.2f}s")
        
        return InsightResult(
            result_type="text",
            content=result["content"],
            metadata=result["metadata"]
        )
    
    async def analyze(
        self,
        user_path: str,
        cancellation_event: Optional[asyncio.Event] = None,
        progress_callback: Optional[Callable[[ProgressEvent], Awaitable[None]]] = None,
        execution_graph: Optional[ExecutionGraph] = None
    ) -> InsightResult:
        """
        Analyze files using either execution graph or simple properties.
        
        Args:
            user_path: User input path (file or folder)
            cancellation_event: Optional cancellation event
            progress_callback: Optional progress callback
            execution_graph: Optional execution graph (if provided, uses graph execution)
        """
        # If execution_graph provided as parameter, use graph execution
        if execution_graph:
            return await self.execute_graph(
                execution_graph=execution_graph,
                user_path=user_path,
                cancellation_event=cancellation_event,
                progress_callback=progress_callback
            )
        
        # If execution_graph property exists on instance, use it
        if hasattr(self, 'execution_graph') and self.execution_graph:
            return await self.execute_graph(
                execution_graph=self.execution_graph,
                user_path=user_path,
                cancellation_event=cancellation_event,
                progress_callback=progress_callback
            )
        
        # Otherwise, use simple single-pattern execution (backward compatibility)
        import time
        start_time = time.time()
        logger.info(f"{self.__class__.__name__}: Starting analysis of path: {user_path}")
        
        # Get files for this path
        path_files = self._get_path_files(user_path)
        if not path_files:
            logger.warning(f"{self.__class__.__name__}: No files found for path: {user_path}")
            from app.core.models import InsightResult
            return InsightResult(
                result_type="text",
                content=f"No files found for path: {user_path}",
                metadata={"user_path": user_path}
            )
        
        # Check file count limit
        limit_error = self._check_file_limit(path_files, user_path)
        if limit_error:
            return limit_error
        
        # Apply file filtering if patterns provided (before creating FileFilter)
        file_patterns = self.file_filter_patterns
        if file_patterns:
            logger.info(f"{self.__class__.__name__}: Applying file filter patterns: {file_patterns}")
            # Filter files by filename patterns
            import re
            compiled_patterns = [re.compile(pattern) for pattern in file_patterns]
            filtered_path_files = []
            for file_path in path_files:
                # Extract filename - handle virtual zip paths (zip_path::internal/file.txt)
                if ZIP_VIRTUAL_PATH_SEPARATOR in file_path:
                    # For virtual paths, use the internal filename part
                    _, internal_path = file_path.split(ZIP_VIRTUAL_PATH_SEPARATOR, 1)
                    file_name = Path(internal_path).name
                else:
                    file_name = Path(file_path).name
                if any(pattern.search(file_name) for pattern in compiled_patterns):
                    filtered_path_files.append(file_path)
            path_files = filtered_path_files
            logger.info(f"{self.__class__.__name__}: {len(path_files)} file(s) matched file filter patterns")
        else:
            logger.debug(f"{self.__class__.__name__}: No file filter patterns, processing all files")
        
        if not path_files:
            logger.warning(f"{self.__class__.__name__}: No files matched file filter patterns for path: {user_path}")
            from app.core.models import InsightResult
            return InsightResult(
                result_type="text",
                content=f"No files matched file filter patterns for path: {user_path}",
                metadata={"user_path": user_path}
            )
        
        logger.debug(f"{self.__class__.__name__}: Line filter pattern: '{self.line_filter_pattern}'")
        logger.debug(f"{self.__class__.__name__}: Reading mode: {self.reading_mode.value}")
        if self.reading_mode == ReadingMode.CHUNKS:
            logger.debug(f"{self.__class__.__name__}: Chunk size: {self.chunk_size:,} bytes")
        
        # Create file filter with already-filtered files
        file_filter = FileFilter(path_files)
        
        # Create line filter with optional regex flags
        regex_flags = 0
        if hasattr(self, 'regex_flags'):
            regex_flags = self.regex_flags if isinstance(self.regex_flags, int) else self.regex_flags()
            logger.debug(f"{self.__class__.__name__}: Using regex flags: {regex_flags}")
        
        line_filter = LineFilter(
            pattern=self.line_filter_pattern,
            reading_mode=self.reading_mode,
            chunk_size=self.chunk_size,
            flags=regex_flags
        )
        
        # Apply line filtering
        try:
            logger.debug(f"{self.__class__.__name__}: Applying line filter to files")
            filter_result = await file_filter.apply(line_filter, cancellation_event, progress_callback)
            logger.info(f"{self.__class__.__name__}: Line filtering complete - {filter_result.get_total_line_count()} matching lines across {filter_result.get_file_count()} file(s)")
        except CancelledError:
            logger.info(f"{self.__class__.__name__}: Analysis cancelled")
            raise
        
        # Process filtered lines
        logger.debug(f"{self.__class__.__name__}: Processing filtered lines")
        result = await self._process_filtered_lines(filter_result)
        
        # Add user_path to metadata
        if result.metadata is None:
            result.metadata = {}
        result.metadata["user_path"] = user_path
        
        total_elapsed = time.time() - start_time
        logger.info(f"{self.__class__.__name__}: Analysis complete for path '{user_path}' in {total_elapsed:.2f}s")
        
        return result

