"""Common insights package - contains commonly used insights."""

