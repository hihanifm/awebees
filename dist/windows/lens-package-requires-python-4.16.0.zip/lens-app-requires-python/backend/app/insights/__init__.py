"""Insights package - exports insight classes for discovery."""

# This file exists to make insights a package
# Individual insight modules will be discovered by the plugin manager

