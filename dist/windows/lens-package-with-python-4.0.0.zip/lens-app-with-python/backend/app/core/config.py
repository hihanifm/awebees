"""Configuration settings for the Lens application."""

import os
from pathlib import Path
from typing import Dict, Any, Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class AIConfig:
    """Configuration for AI-powered analysis."""
    
    # Global AI toggle
    ENABLED: bool = os.getenv("AI_ENABLED", "false").lower() == "true"
    
    # OpenAI API configuration
    BASE_URL: str = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    API_KEY: Optional[str] = os.getenv("OPENAI_API_KEY")
    MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    
    # Request parameters
    MAX_TOKENS: int = int(os.getenv("OPENAI_MAX_TOKENS", "2000"))
    TEMPERATURE: float = float(os.getenv("OPENAI_TEMPERATURE", "0.7"))
    TIMEOUT: int = int(os.getenv("OPENAI_TIMEOUT", "60"))
    
    # Predefined system prompts
    SYSTEM_PROMPTS: Dict[str, str] = {
        "summarize": """You are a log analysis assistant. Summarize the following log analysis results concisely.

Focus on:
- Key findings and patterns
- Critical issues identified
- Important statistics

Keep it brief and actionable, using bullet points.""",
        
        "explain": """You are a log analysis expert. Analyze the following log data and explain:

- What patterns and trends you observe
- What these patterns indicate about system behavior
- Potential root causes of issues
- Technical insights and correlations

Be thorough but concise. Use technical terminology when appropriate.""",
        
        "recommend": """You are a system reliability expert. Based on the following log analysis, provide:

1. **Immediate Actions**: Critical issues requiring immediate attention
2. **Short-term Fixes**: Problems to address soon
3. **Long-term Improvements**: Preventive measures and optimizations
4. **Monitoring Recommendations**: What to watch for

Be specific and practical. Prioritize recommendations by severity."""
    }
    
    @classmethod
    def is_configured(cls) -> bool:
        """Check if AI is properly configured."""
        return bool(cls.API_KEY) and cls.ENABLED
    
    @classmethod
    def to_dict(cls, include_sensitive: bool = False) -> Dict[str, Any]:
        """
        Convert configuration to dictionary.
        
        Args:
            include_sensitive: Whether to include sensitive data (API key)
        
        Returns:
            Configuration as dictionary
        """
        config = {
            "enabled": cls.ENABLED,
            "base_url": cls.BASE_URL,
            "model": cls.MODEL,
            "max_tokens": cls.MAX_TOKENS,
            "temperature": cls.TEMPERATURE,
            "timeout": cls.TIMEOUT,
            "is_configured": cls.is_configured()
        }
        
        if include_sensitive:
            config["api_key"] = cls.API_KEY
        else:
            # Mask API key for display
            if cls.API_KEY:
                key_preview = cls.API_KEY[:8] + "..." if len(cls.API_KEY) > 8 else "***"
                config["api_key_preview"] = key_preview
            else:
                config["api_key_preview"] = None
        
        return config
    
    @classmethod
    def _get_env_file_path(cls) -> Path:
        """Get the path to the .env file."""
        # Start from this file's location and go up to backend directory
        backend_dir = Path(__file__).parent.parent.parent
        return backend_dir / ".env"
    
    @classmethod
    def _persist_to_env(cls, updates: Dict[str, Any]) -> None:
        """
        Persist AI configuration updates to .env file.
        
        Args:
            updates: Dictionary of config updates to persist
        """
        env_file = cls._get_env_file_path()
        
        # Mapping of config keys to environment variable names
        env_key_mapping = {
            "enabled": "AI_ENABLED",
            "base_url": "OPENAI_BASE_URL",
            "api_key": "OPENAI_API_KEY",
            "model": "OPENAI_MODEL",
            "max_tokens": "OPENAI_MAX_TOKENS",
            "temperature": "OPENAI_TEMPERATURE",
            "timeout": "OPENAI_TIMEOUT"
        }
        
        # Read existing .env file or create empty dict
        env_vars = {}
        if env_file.exists():
            with open(env_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    # Skip empty lines and comments
                    if not line or line.startswith('#'):
                        continue
                    # Parse KEY=VALUE
                    if '=' in line:
                        key, value = line.split('=', 1)
                        env_vars[key.strip()] = value.strip()
        
        # Update with new values
        for config_key, value in updates.items():
            if config_key in env_key_mapping:
                env_key = env_key_mapping[config_key]
                # Convert boolean to string
                if isinstance(value, bool):
                    env_vars[env_key] = "true" if value else "false"
                else:
                    env_vars[env_key] = str(value)
        
        # Write back to .env file
        with open(env_file, 'w') as f:
            f.write("# Lens AI Configuration\n")
            f.write("# Auto-generated from settings panel\n\n")
            
            # Write AI settings first
            ai_keys = ["AI_ENABLED", "OPENAI_BASE_URL", "OPENAI_API_KEY", 
                       "OPENAI_MODEL", "OPENAI_MAX_TOKENS", "OPENAI_TEMPERATURE", 
                       "OPENAI_TIMEOUT"]
            for key in ai_keys:
                if key in env_vars:
                    f.write(f"{key}={env_vars[key]}\n")
            
            # Write other environment variables
            f.write("\n# Other Settings\n")
            for key, value in env_vars.items():
                if key not in ai_keys:
                    f.write(f"{key}={value}\n")
    
    @classmethod
    def update_from_dict(cls, config: Dict[str, Any], persist: bool = True) -> None:
        """
        Update configuration from dictionary.
        
        Args:
            config: Configuration dictionary
            persist: Whether to persist changes to .env file (default: True)
        """
        if "enabled" in config:
            cls.ENABLED = bool(config["enabled"])
        
        if "base_url" in config:
            cls.BASE_URL = str(config["base_url"])
        
        if "api_key" in config and config["api_key"]:
            cls.API_KEY = str(config["api_key"])
        
        if "model" in config:
            cls.MODEL = str(config["model"])
        
        if "max_tokens" in config:
            cls.MAX_TOKENS = int(config["max_tokens"])
        
        if "temperature" in config:
            cls.TEMPERATURE = float(config["temperature"])
        
        if "timeout" in config:
            cls.TIMEOUT = int(config["timeout"])
        
        # Persist to .env file if requested
        if persist:
            cls._persist_to_env(config)


class AppConfig:
    """General application configuration."""
    
    # Server settings
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "34001"))
    
    # Frontend settings
    FRONTEND_URL: str = os.getenv("FRONTEND_URL", "http://localhost:34000")
    SERVE_FRONTEND: bool = os.getenv("SERVE_FRONTEND", "false").lower() == "true"
    
    # Logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    
    # CORS
    CORS_ORIGINS: list = [
        "http://localhost:34000",
        "http://127.0.0.1:34000",
        FRONTEND_URL
    ]
    
    # Enable profiling
    ENABLE_PROFILING: bool = os.getenv("ENABLE_PROFILING", "false").lower() == "true"


# Export config classes
__all__ = ["AIConfig", "AppConfig"]

