"""System insights package - contains system-level insights."""

